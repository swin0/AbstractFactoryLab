public class MozzarellaCheese extends Cheese {
    public String toString() {
        return "Shredded Mozzarella Cheese";
    }
}
