public abstract class Cheese {
    public abstract String toString();
}
