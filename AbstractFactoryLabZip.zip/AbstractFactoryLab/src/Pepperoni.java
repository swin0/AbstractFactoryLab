public abstract class Pepperoni {
    public abstract String toString();
}
