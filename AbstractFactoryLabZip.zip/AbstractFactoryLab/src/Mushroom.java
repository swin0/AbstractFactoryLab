public class Mushroom extends Veggies {
    public String toString() {
        return "Mushroom";
    }
}
