public class Main {
    public static void main(String[] args) {
        PizzaStore nyStore = new NYPizzaStore();
        PizzaStore chicagoStore = new ChicagoPizzaStore();
        
        //example output demonstrating two pizza orders from different stores

        Pizza pizza = nyStore.orderPizza("cheese");
        System.out.println("Sydney ordered a " + pizza.getName() + "\n");

        pizza = chicagoStore.orderPizza("clam");
        System.out.println("Nicole ordered a " + pizza.getName() + "\n");
    }
}
