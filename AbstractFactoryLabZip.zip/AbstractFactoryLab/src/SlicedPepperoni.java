public class SlicedPepperoni extends Pepperoni {
    public String toString() {
        return "Sliced Pepperoni";
    }
}
