public class MarinaraSauce extends Sauce {
    public String toString() {
        return "Marinara Sauce";
    }
}
