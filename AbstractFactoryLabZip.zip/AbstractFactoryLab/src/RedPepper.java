public class RedPepper extends Veggies {
    public String toString() {
        return "Red Pepper";
    }
}
