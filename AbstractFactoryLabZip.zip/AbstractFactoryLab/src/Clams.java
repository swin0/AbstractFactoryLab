public abstract class Clams {
    public abstract String toString();
}
