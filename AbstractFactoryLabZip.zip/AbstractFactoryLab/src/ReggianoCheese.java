public class ReggianoCheese extends Cheese {
    public String toString() {
        return "Reggiano Cheese";
    }
}
