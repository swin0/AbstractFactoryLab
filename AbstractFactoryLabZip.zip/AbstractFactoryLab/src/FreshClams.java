public class FreshClams extends Clams {
    public String toString() {
        return "Fresh Clams";
    }
}
