public abstract class Sauce {
    public abstract String toString();
}
