public class ThickCrustDough implements Dough {
    public String toString() {
        return "Thick Crust style extra thick crust dough";
    }
}
