public class FrozenClams extends Clams {
    public String toString() {
        return "Frozen Clams";
    }
}
