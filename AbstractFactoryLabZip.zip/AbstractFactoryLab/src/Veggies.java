public abstract class Veggies {
    public abstract String toString();
}
