public class Onion extends Veggies {
    public String toString() {
        return "Onion";
    }
}
