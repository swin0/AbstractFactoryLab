public class Garlic extends Veggies {
    public String toString() {
        return "Garlic";
    }
}
