public class PlumTomatoSauce extends Sauce {
    public String toString() {
        return "Plum Tomato Sauce";
    }
}
